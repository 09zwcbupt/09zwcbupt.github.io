---
title: About Me
author: richard
layout: page
dsq_thread_id:
  - 4410050102
dsq_needs_sync:
  - 1
---
  
<a class="twitter-timeline" href="https://twitter.com/weichenzhao" data-widget-id="278759035937882113">@weichenzhao 的推文</a>  
  
<a href="http://richardzhao.me/wp-content/uploads/2013/10/resume.pdf" title="cv" target="_blank">cv</a>