---
title: '[转载&amp;凑热闹]你的Iphone信息被泄露了么~？'
author: richard
layout: post
permalink: /2012/09/04/%e8%bd%ac%e8%bd%bd%e5%87%91%e7%83%ad%e9%97%b9%e4%bd%a0%e7%9a%84iphone%e4%bf%a1%e6%81%af%e8%a2%ab%e6%b3%84%e9%9c%b2%e4%ba%86%e4%b9%88%ef%bc%9f/
categories:
  - 技术
---
来源：煎蛋

著名黑客组织“无名氏”（Anonymous）的分支 <a href="https://twitter.com/anonymousirc" rel="external" target="_blank">AntiSec</a> 声称他们掌握额超过120万苹果设备ID，同时握有这些用户姓名、手机号码、地址等信息。

AntiSec 还通过发表声明将入侵的途径公开，着实羞辱了 FBI。在2012年3月第二个星期，黑客通过 FBI 网络行动组探员 Christopher K. Stangl 使用的一部戴尔 Vostro 笔记本上存在的漏洞（#这个实在看不懂，技术控麻烦跳转看原文），将一份列有12367232个苹果设备ID的名单盗走，它还包含了UDID（唯一设备识别符）、用户姓名、设备名称和类型、苹果推送通知标记、邮编、手机号码、地址等重要信息。<!--more-->

AntiSec 还表示此举是为了唤起外界对 FBI 监控公民情况的关注，而 TNW 也提供了方法以便用户<a href="http://thenextweb.com/apple/2012/09/04/heres-check-apple-device-udid-compromised-antisec-leak/" rel="external" target="_blank">检测设备</a>是否在泄露名单上。

来源地址：<http://jandan.net/2012/09/04/antisec-leak-12m-apple-id.html>