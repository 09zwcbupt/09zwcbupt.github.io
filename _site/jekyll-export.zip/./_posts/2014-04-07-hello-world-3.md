---
title: 'Hello world&#8230;'
author: richard
layout: post
permalink: /2014/04/07/hello-world-3/
categories:
  - Uncategorized
---
换回到LA的VPS了&#8230; 排版和图片还有些问题。网站现在的内容基于3月27号的备份。

[吐槽]思科满满的恶意啊: <a title="Cisco Offers OpFlex as OpenFlow Alternative" href="http://tools.ietf.org/html/draft-smith-opflex-00" target="_blank">http://tools.ietf.org/html/draft-smith-opflex-00</a>